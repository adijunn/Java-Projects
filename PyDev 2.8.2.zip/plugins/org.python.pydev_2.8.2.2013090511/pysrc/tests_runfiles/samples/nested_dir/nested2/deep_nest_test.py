import unittest

class SampleTest(unittest.TestCase):
    
    def setUp(self):
        return

    def tearDown(self):
        return

    def test_non_unique_name(self):
        pass

    def test_asdf2(self):
        pass

    def test_i_am_a_unique_test_name(self):
        pass


if __name__ == '__main__':
    unittest.main()
